Name: Yuhai Li
UID: 104844760
Email: liyuhai6666@gmail.com

readme.txt:	contains the information and brief descriptions of each file
team.txt:	contains the UIDs of group members
sql:		folder that has updated create.sql and load.sql
www:
home.php:	home page
I1.php, I2.php, 
I3.php, I4.php:	Input pages
actor.php:	Actor browsing page
movie.php:	Movie browsing page
search.php:	Search page
