Name: Yuhai Li
UID: 104844760
Email: liyuhai6666@gmail.com

readme.txt:	contains the information and brief description of all the files
team.txt:	contains the UID of group members
create.sql:	creates tables follow the required schemas
load.sql:	loads files to the tables built by create.sql
queries.sql:	the answers of question and other two queries
query.php:	php file that prompts user to enter query and returns result
violate.sql:	contains the queries that violates the constraints
